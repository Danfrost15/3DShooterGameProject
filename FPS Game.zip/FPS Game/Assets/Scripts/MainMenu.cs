using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenu : MonoBehaviour
{
    public GameObject Instruction_Panel;
    public GameObject Credits_Panel;
 
    public void StartGame()
    {
        SceneManager.LoadScene("Level 1");
    }

    public void Instructions()
    {
        Instruction_Panel.SetActive(true);
        
    }

    public void Credits()
    {
        Credits_Panel.SetActive(true);
    }

    public void Quit()
    {
        Application.Quit();
    }



}
