using UnityEngine;
using TMPro; // Ensure you have TextMeshPro imported

public class Score : MonoBehaviour
{
    public static int CurrentScore { get; private set; } = 0;
    public TextMeshProUGUI scoreText; // Assign in Inspector (optional)

    void Start()
    {
        UpdateScoreUI();
    }

    public void AddPoints(int points)
    {
        CurrentScore += points;
        // Update UI if a Score instance exists
        if (Instance != null)
            Instance.UpdateScoreUI();
    }

    // Singleton pattern for easy access
    public static Score Instance { get; private set; }

    void Awake()
    {
        Instance = this;
    }

    void UpdateScoreUI()
    {
        if (scoreText != null)
            scoreText.text = "Score: " + CurrentScore;
    }
}
