using UnityEngine;

public class AudioManager : MonoBehaviour
{
    public static AudioManager Instance { get; private set; }

    [Header("Audio Sources")]
    [SerializeField] private AudioSource musicSource;
    [SerializeField] private AudioSource sfxSource;

    [Header("Audio Clips")]
    [SerializeField] private AudioClip buttonClickClip;
    [SerializeField] private AudioClip menuMusicClip;
    [SerializeField] private AudioClip gameMusicClip;

    private void Awake()
    {
        // Singleton pattern to ensure only one AudioManager exists
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
            return;
        }
    }

    private void Start()
    {
        PlayMenuMusic();
    }

    /// <summary>
    /// Plays a one-shot sound effect, e.g., for button clicks.
    /// </summary>
    public void PlayButtonClick()
    {
        if (buttonClickClip != null)
        {
            sfxSource.PlayOneShot(buttonClickClip);
        }
    }

    /// <summary>
    /// Plays menu music in a loop.
    /// </summary>
    public void PlayMenuMusic()
    {
        if (musicSource != null && menuMusicClip != null)
        {
            musicSource.clip = menuMusicClip;
            musicSource.loop = true;
            musicSource.Play();
        }
    }

    /// <summary>
    /// Plays game music in a loop.
    /// </summary>
    public void PlayGameMusic()
    {
        if (musicSource != null && gameMusicClip != null)
        {
            musicSource.clip = gameMusicClip;
            musicSource.loop = true;
            musicSource.Play();
        }
    }

    /// <summary>
    /// Stops the music source.
    /// </summary>
    public void StopMusic()
    {
        if (musicSource != null)
        {
            musicSource.Stop();
        }
    }
}