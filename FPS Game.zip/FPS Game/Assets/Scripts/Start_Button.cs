using UnityEngine;
using UnityEngine.SceneManagement;

public class Start_Button : MonoBehaviour
{
   public void Begin()
    {
        SceneManager.LoadScene("MainMenu");
    }
}
