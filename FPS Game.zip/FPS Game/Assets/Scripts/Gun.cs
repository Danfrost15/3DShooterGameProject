using UnityEngine;
using TMPro;

public class Gun : MonoBehaviour
{
    public GameObject bulletPrefab;
    public Transform firePoint;
    public TextMeshProUGUI Ammo_Text;

    public int Ammo = 0;

    public int Max_Ammo = 20;

    private int Min_Ammo = 0;

    public bool Can_shoot;

    private void Start()
    {
        Ammo = Max_Ammo;
        Can_shoot = true;
    }
    void Update()
    {
        if (Input.GetButtonDown("Fire1") && Can_shoot == true)
        {
            Shoot();
        }
       
    }

    void Shoot()
    {
        if(Ammo > Min_Ammo) 
        {
            Can_shoot = true;
            Instantiate(bulletPrefab, firePoint.position, firePoint.rotation);
            Ammo -= 1;
            UpdateAmmoText();
        }
        else if (Ammo <= Min_Ammo)
        {
            Can_shoot = false;
            Debug.Log("No bullets");
        }

    }

    public void Add_Ammo(int Mag)
    {
        if(Ammo < Max_Ammo)
        {
            Ammo += Mag;
            UpdateAmmoText();
            Can_shoot = true;
        }
    }

    public void UpdateAmmoText()
    {
        if(Ammo_Text != null)
        Ammo_Text.text ="Ammo:" + Ammo.ToString();
    }
}
