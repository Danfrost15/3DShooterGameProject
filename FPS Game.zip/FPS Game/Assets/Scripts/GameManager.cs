using UnityEngine;
using TMPro; // Ensure you have TextMeshPro imported
using UnityEngine.SceneManagement;
public class GameManager : MonoBehaviour
{
    public TextMeshProUGUI timerText;      // Assign in Inspector
    public GameObject Win_panel;
    public GameObject GameOver_panel;


    private float playTime = 0f;
    private bool gameEnded = false;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        if (gameEnded) return;

        playTime += Time.deltaTime;
        UpdateTimerUI();

        int enemyCount = GameObject.FindGameObjectsWithTag("Enemy").Length;
        if (enemyCount == 0)
        {
            Win();
        }
    }

    void UpdateTimerUI()
    {
        int minutes = Mathf.FloorToInt(playTime / 60F);
        int seconds = Mathf.FloorToInt(playTime % 60F);
        timerText.text = $"Time: {minutes:00}:{seconds:00}";
    }

    public void Win()
    {
        gameEnded = true;
        Win_panel.SetActive(true);

        // Stop player from shooting
        GameObject player = GameObject.FindGameObjectWithTag("Player");
        if (player != null)
        {
            Gun gun = player.GetComponentInChildren<Gun>();
            if (gun != null)
            {
                gun.Can_shoot = false; // Prevent shooting
            }
        }

        // Show and unlock the mouse cursor for UI interaction
        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;

        Time.timeScale = 0f;
    }

    public void GameOver()
    {
        gameEnded = true;
        GameOver_panel.SetActive(true);
        Time.timeScale = 0f;
        
    }

    public void Restart()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        Time.timeScale = 1f; // Reset time scale
        Cursor.lockState = CursorLockMode.Locked; // Lock cursor again
        Cursor.visible = false; // Hide cursor  
    }

    public void Mainmenu()
    {
        SceneManager.LoadScene("MainMenu");
    }
}
