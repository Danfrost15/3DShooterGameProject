using UnityEngine;
using UnityEngine.AI;

public class Enemy : MonoBehaviour
{
    public Transform Player_pos;

    public NavMeshAgent Agent;

    public float health = 50f;

    public Score score;

    private void Start()
    {
        Player_pos = GameObject.FindGameObjectWithTag("Player").transform;

        score = FindAnyObjectByType<Score>();
    }
    // Update is called once per frame
    void Update()
    {
        if (Player_pos != null && Agent != null) { 
            Agent.SetDestination(Player_pos.position);
        }
    }
    public void TakeDamage(float amount)
    {
        health -= amount;
        if (health <= 0f)
        {
            Die();
            score.AddPoints(10); // Assuming Score script has an AddPoints method
        }
    }

    void Die()
    {
        Destroy(gameObject);
    }
    private void OnTriggerEnter(Collider other)
    {
        PlayerHealth health = other.GetComponent<PlayerHealth>();
        if(other.tag == "Player")
        {
            health.Damage(10f);
        }
    }
}
