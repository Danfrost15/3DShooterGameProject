using Unity.VisualScripting;
using UnityEngine;

public class Back_Button : MonoBehaviour
{
    public void Back()
    {
        this.gameObject.SetActive(false);
    }
}
