using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ammo_Pickup : MonoBehaviour
{
    public Gun gun;
    private Renderer rend;
    private Collider col;

    private void Awake()
    {
        rend = GetComponent<Renderer>();
        col = GetComponent<Collider>();
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Player")
        {
            gun.Add_Ammo(10);
            StartCoroutine(HandlePickup());
        }
    }

    IEnumerator HandlePickup()
    {
        rend.enabled = false;   // Make invisible
        col.enabled = false;    // Disable collider to prevent re-triggering
        yield return new WaitForSeconds(5f);
        rend.enabled = true;    // Make visible again
        col.enabled = true;     // Enable collider
    }
}
