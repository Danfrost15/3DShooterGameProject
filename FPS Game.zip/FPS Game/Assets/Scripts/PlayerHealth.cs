using TMPro;
using UnityEngine;

public class PlayerHealth : MonoBehaviour
{
    public float health = 100f;

    public TextMeshProUGUI healthText;

    GameManager gameManager;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        UpdatehealthText();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void Damage(float damage)
    {
        health -= damage;
        UpdatehealthText();

        if(health <= 0)
        {
            die();
        }
    }

    void die()
    {
        Time.timeScale = 0;
        gameManager = FindAnyObjectByType<GameManager>();
        gameManager.GameOver();
    }

    void UpdatehealthText()
    {
        if(healthText != null)
        {
            healthText.text ="Health: " + health.ToString();
        }
    }

    public void Add_Health(float amount)
    {
        if(health < 100f)
        {
            health += amount;
            UpdatehealthText();
        }
        
    }
}
