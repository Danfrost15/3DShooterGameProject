using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Health_Pickup : MonoBehaviour
{
    public PlayerHealth PlayerHealth;
    private Renderer rend;
    private Collider col;

    private void Awake()
    {
        rend = GetComponent<Renderer>();
        col = GetComponent<Collider>();
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Player")
        {
            PlayerHealth.Add_Health(20f);
            StartCoroutine(HandlePickup());
        }
    }

    IEnumerator HandlePickup()
    {
        rend.enabled = false;   // Make invisible
        col.enabled = false;    // Disable collider to prevent re-triggering
        yield return new WaitForSeconds(5f);
        rend.enabled = true;    // Make visible again
        col.enabled = true;     // Enable collider
    }
}
